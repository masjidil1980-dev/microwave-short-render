# Rencana kamera (kamera selalu mengarah tepat ke pusat objek yang disebut pada kata itu)
| Shot | Waktu | Lokasi | Gerak kamera | Objek |
|---|---|---|---|---|
| hook | 0.15-4.25 | Lab radar | Close batang cokelat di saku -> wajah Percy -> mundur lebar ke mesin radar | Cokelat meleleh (menetes) pada kata "meleleh" |
| year | 4.63-9.56 | Lab radar | Kalender 1945 -> Percy -> piringan radar | Cincin gelombang menyala pada "menyala" |
| choco | 9.94-12.86 | Lab radar | Lanjut dari piringan, ikuti gelombang ke saku | Cokelat meleleh lagi pada "meleleh" |
| corn | 13.24-17.61 | Meja uji 1 | Percy + asisten -> karung JAGUNG -> mangkuk | Jagung meletus pada "meletus" |
| egg | 17.99-22.26 | Meja uji 2 | Lebar -> telur bergetar -> wajah rekan | Telur meledak pada "meledak", kuning telur kena wajah |
| wave | 22.64-27.45 | Panggung gelombang | Piringan -> cincin -> potongan makanan -> murid "OHH!" | Molekul memanas dari tengah |
| oven | 27.83-34.02 | Pabrik 1947 | Oven lebar -> tag DIJUAL -> penggaris tinggi -> papan 300+ KG | Penggaris naik pada "dua meter" |
| close | 34.41-37.43 | Dapur modern | Poster radar -> microwave -> mangkuk nasi | Microwave menyala, uap, "TING!" |
Dip krem 0.4 s di tiap pindah lokasi; year -> choco kamera menyambung.
