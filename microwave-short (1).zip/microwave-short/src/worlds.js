import * as THREE from 'three';
import {INK, rng, toon, box, cyl, sign, crate, paintTex, ink} from './kit.js';
import {character} from './char.js';
import {wordT} from './camera.js';
import * as P from './props.js';

// Cokelat meleleh -> oven microwave. Semua adegan di dalam ruangan / panggung (bukan rumah + awan).
export const LOC = {lab: 0, wave: 100, factory: 200, kitchen: 300};

export const ease = (t, a, b) => { const x = Math.min(1, Math.max(0, (t - a) / (b - a))); return x * x * (3 - 2 * x); };
const pop = (o, t, t0) => { // pop-in with a small overshoot
  const k = Math.min(1, Math.max(0, (t - t0) / 0.5));
  const s = ease(t, t0, t0 + 0.28) * (1 + 0.14 * Math.sin(k * Math.PI));
  o.visible = t >= t0; o.scale.setScalar(Math.max(0.001, s));
};
const at = P.at;
const G = () => new THREE.Group();
const bmat = (c, o = {}) => new THREE.MeshBasicMaterial({color: c, ...o});
const S = (text, w, h, x, y, z, o = {}, ry = 0) => { const s = sign(text, w, h, o); s.position.set(x, y, z); s.rotation.y = ry; return s; };
const FONT = (px) => `bold ${px}px Arial, sans-serif`;

function room(ox, {w = 14, h = 5, d = 10, wall = '#efe0c4', floor = '#a7764e', seed = 4, stains = 14} = {}) {
  const g = G();
  const wt = paintTex(wall, {seed, stains}); wt.repeat.set(Math.max(2, Math.round(w / 8)), 1);
  const walls = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), toon('#ffffff', wt, {side: THREE.BackSide}));
  walls.position.set(ox, h / 2, 0); walls.receiveShadow = true; g.add(walls);
  const ft = paintTex(floor, {seed: seed + 1, stripes: (gg, W, H) => { gg.strokeStyle = 'rgba(60,30,15,0.35)'; gg.lineWidth = 2; for (let i = 0; i < 10; i++) { gg.beginPath(); gg.moveTo(0, i * H / 10); gg.lineTo(W, i * H / 10); gg.stroke(); } }});
  ft.repeat.set(Math.round(w / 5), 2);
  const fl = new THREE.Mesh(new THREE.BoxGeometry(w - 0.02, 0.1, d - 0.02), toon('#ffffff', ft)); fl.position.set(ox, 0.0, 0); fl.receiveShadow = true; g.add(fl);
  g.add(box(w, 0.25, 0.15, '#6b4a36', {x: ox, y: 0.12, z: -d / 2 + 0.1, thick: 0.01}));
  return g;
}
const hang = (W, x, y, z, c = '#2f5d62') => {
  W.add(cyl(0.02, 0.02, 1.0, '#2b2b2e', {x, y: y + 0.5, z}));
  W.add(cyl(0.15, 0.5, 0.38, c, {x, y, z, seg: 14}));
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), bmat('#fff1c0')); b.position.set(x, y - 0.18, z); W.add(b);
};

// ---------- reusable gadgets ----------
function dish(r = 1.0, face = 'x-') { // parabolic radar dish; face '+y' | 'x+' | 'x-'
  const inner = G();
  const R = r * 1.47;
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(R, 40, 14, 0, Math.PI * 2, Math.PI - 0.75, 0.75), toon('#e3e7ea', null, {side: THREE.DoubleSide}));
  bowl.position.y = R; ink(bowl, 0.025, false); inner.add(bowl);
  inner.add(cyl(0.22 * r, 0.3 * r, 0.3 * r, '#8d9199', {y: -0.12 * r}));
  inner.add(cyl(0.05 * r, 0.05 * r, 0.62 * r, '#2b2b2e', {y: 0.34 * r}));
  const tip = new THREE.Mesh(new THREE.SphereGeometry(0.1 * r, 10, 8), bmat('#ffb066')); tip.position.y = 0.68 * r; inner.add(tip);
  for (let i = 0; i < 3; i++) { const a = i * 2.094; const s = cyl(0.015 * r, 0.015 * r, 1.0 * r, '#444', {seg: 5, thick: 0.004}); s.position.set(Math.cos(a) * 0.5 * r, 0.38 * r, Math.sin(a) * 0.5 * r); s.rotation.set(Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5); inner.add(s); }
  const o = G(); o.add(inner);
  if (face === 'x-') o.rotation.z = Math.PI / 2; else if (face === 'x+') o.rotation.z = -Math.PI / 2;
  return o;
}
function horn() { // microwave horn pointing +z
  const g = G();
  const m = cyl(0.3, 0.1, 0.7, '#c9ced4', {seg: 4, thick: 0.02}); m.rotation.x = Math.PI / 2; m.rotation.y = Math.PI / 4; m.position.z = 0.35; g.add(m);
  const back = box(0.28, 0.28, 0.35, '#2f8f8a', {z: -0.18, thick: 0.02}); g.add(back);
  const eye = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), bmat('#ffb066')); eye.position.set(0, 0.17, -0.18); g.add(eye);
  return g;
}
function emitter(len, {color = '#7fe7ff', n = 7, r0 = 0.25, r1 = 1.0} = {}) { // expanding wave rings travelling along local +z
  const g = G(); const rings = [];
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(new THREE.TorusGeometry(1, 0.04, 6, 36), new THREE.MeshBasicMaterial({color, transparent: true, opacity: 0.8, depthWrite: false}));
    g.add(m); rings.push(m);
  }
  g.userData.update = (t, on = 1, speed = 0.55) => {
    g.visible = on > 0.01;
    rings.forEach((m, i) => {
      const s = (((t * speed + i / n) % 1) + 1) % 1;
      m.position.z = s * len; const r = r0 + (r1 - r0) * s; m.scale.set(r, r, 1);
      m.material.opacity = Math.sin(s * Math.PI) * 0.85 * on;
    });
  };
  return g;
}
function chocolate(body) { // chocolate bar sticking out of the engineer's pocket (child of the character body)
  const g = G(); g.position.set(0.12, 0.96, 0.06); g.rotation.z = -0.22; body.add(g);
  const wrap = box(0.22, 0.2, 0.05, '#c43d32', {y: 0.1, thick: 0.012}); g.add(wrap);
  g.add(box(0.225, 0.04, 0.055, '#e6c24a', {y: 0.17, thick: 0.006, edges: false}));
  const choc = box(0.2, 0.26, 0.05, '#6b3a22', {y: 0.33, thick: 0.012}); g.add(choc);
  for (let i = 0; i < 2; i++) g.add(box(0.2, 0.012, 0.052, '#4a2615', {y: 0.28 + i * 0.1, thick: 0.002, edges: false}));
  const dripMat = toon('#5a3320');
  const drip = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1, 10), dripMat); ink(drip, 0.012, false); body.add(drip);
  const blob = new THREE.Mesh(new THREE.SphereGeometry(0.085, 12, 8), dripMat); ink(blob, 0.012, false); body.add(blob);
  const drops = [0, 1, 2].map(() => { const d = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), dripMat); body.add(d); return d; });
  g.userData.update = (m, t) => {
    choc.scale.y = 1 - 0.6 * m; choc.position.y = 0.2 + 0.13 * choc.scale.y * 1;
    choc.material.color && choc.material.color.set(m > 0.2 ? '#7a4528' : '#6b3a22');
    const len = 0.55 * m;
    drip.visible = blob.visible = m > 0.02; drops.forEach((d) => { d.visible = m > 0.4; });
    drip.scale.set(1, Math.max(len, 0.001), 1); drip.position.set(0.12, 0.93 - len / 2, 0.09);
    blob.position.set(0.12, 0.93 - len, 0.09); blob.scale.setScalar(0.6 + m * 0.6);
    drops.forEach((d, i) => { const k = (((t * 0.9 + i / 3) % 1) + 1) % 1; d.position.set(0.12 + (i - 1) * 0.03, 0.93 - len - k * 0.45, 0.09); d.scale.setScalar(Math.max(0.01, 1 - k)); });
  };
  return g;
}
function popcorn(cx, cy, cz, seed, N = 64) {
  const g = G(); const r = rng(seed);
  const kMat = toon('#e0a92e'), pMat = toon('#fff4d4');
  const geo = new THREE.IcosahedronGeometry(0.09, 0);
  const items = Array.from({length: N}, () => {
    const m = new THREE.Mesh(geo, kMat); ink(m, 0.02, false); g.add(m);
    return {m, a: r() * 6.28, rad: r() * 0.2, vx: (r() - 0.5) * 3.0, vy: 2.4 + r() * 3.2, vz: (r() - 0.25) * 2.6, d: r() * 0.7, spin: r() * 6};
  });
  g.userData.update = (t, t0) => {
    for (const it of items) {
      const tau = t - t0 - it.d;
      if (tau < 0) {
        const sh = ease(t, t0 - 0.9, t0) * 0.012;
        it.m.material = kMat; it.m.scale.setScalar(0.4);
        it.m.position.set(cx + Math.cos(it.a) * it.rad + Math.sin(t * 55 + it.spin) * sh, cy + 0.05, cz + Math.sin(it.a) * it.rad * 0.6);
      } else {
        it.m.material = pMat; it.m.scale.setScalar(Math.min(1, 0.4 + tau * 6));
        const gr = 9, y0 = cy + 0.05;
        const tl = (it.vy + Math.sqrt(it.vy * it.vy + 2 * gr * (y0 - 0.12))) / gr; // landing time
        const tc = Math.min(tau, tl);
        it.m.position.set(cx + it.vx * tc * 0.7, Math.max(0.12, y0 + it.vy * tau - 0.5 * gr * tau * tau), cz + it.vz * tc * 0.7);
        it.m.rotation.set(tau * 5 + it.spin, tau * 4, 0);
      }
    }
  };
  return g;
}
function splatShape(r, seed, n = 14) {
  const rr = rng(seed); const pts = [];
  for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; const k = r * (0.7 + rr() * 0.5 + (i % 2 ? 0.25 : 0)); pts.push(new THREE.Vector2(Math.cos(a) * k, Math.sin(a) * k)); }
  return new THREE.ShapeGeometry(new THREE.Shape(pts));
}

export function buildWorld() {
  const W = new THREE.Group();
  const chars = [];

  // =====================================================================
  // LAB RADAR 1945 (shots: hook, year, choco, corn, egg)
  // =====================================================================
  const L = LOC.lab;
  W.add(room(L, {w: 36, h: 7, d: 12, wall: '#9fd0cf', floor: '#a7764e', seed: 8}));
  W.add(S('LAB RADAR', 6.4, 1.2, L, 5.5, -5.9, {bg: '#1f3f47', fg: '#ffe9b0', w: 900, h: 170, font: FONT(110)}));
  W.add(S('1945', 2.6, 1.9, L - 12, 3.6, -5.9, {bg: '#f4ead4', w: 520, h: 380, font: FONT(190)}));
  for (let i = 0; i < 6; i++) hang(W, L - 15 + i * 6, 6.0, -1);
  // rugs under the three stations
  for (const x of [-9.5, 0, 9]) W.add(at(P.rug(5.5, 4.2, '#2f5d62', '#e0b04a'), L + x, 0.06, -0.2));
  // back wall: shelves, cabinets, posters, clock
  [-16, -13.2, -6.6, -3.0, 3.8, 6.2, 12.8, 15.6].forEach((x, i) => W.add(at(P.bookshelf(i + 3, 2.4, 2.8), L + x, 0.05, -5.6)));
  [-8.2, 0.9, 7.2, 10.8].forEach((x, i) => W.add(at(P.filingCabinet(i % 2 ? '#8f7d6a' : '#7d8a8f'), L + x, 0.05, -5.5)));
  W.add(at(P.toolRack(1), L - 11, 0, -5.9), at(P.toolRack(2), L + 14, 0, -5.9));
  [['RADAR', '#cfe3f0', -9.5], ['GELOMBANG', '#e6d39a', -1.5], ['LISTRIK', '#f2c12e', 5.0], ['TUBE', '#cfe3f0', 15.5]].forEach(([tx, bg, x]) => { const p = P.poster(tx, 1.4, 1.8, bg); at(p, L + x, 3.3, -5.95); W.add(p); });
  W.add(at(P.wallClock(), L + 9.8, 4.6, -5.9), at(P.wallClock(), L - 14.8, 4.6, -5.9));
  // side benches with instruments
  for (const [x, z] of [[-14.5, 1.5], [14.5, 1.5], [-15, -2.5], [15, -2.5]]) {
    const d = P.desk(2.4, '#7a4f33'); d.position.set(L + x, 0.05, z); d.rotation.y = x < 0 ? Math.PI / 2 : -Math.PI / 2; W.add(d);
    W.add(at(P.tvMonitor(['RADAR', 'OSILOSKOP'][Math.abs(z) > 2 ? 0 : 1]), L + x + (x < 0 ? 0.1 : -0.1), 1.0, z), at(P.papers(5, x + z), L + x, 1.0, z + 0.7), at(P.deskLamp(), L + x, 1.0, z - 0.7));
  }
  for (const [x, z, c] of [[-17, -4.8, '#2f6db3'], [-16.4, -4.4, '#c43d32'], [17, -4.8, '#d9a441'], [16.4, -4.2, '#2f6db3']]) W.add(at(P.barrel(c), L + x, 0.05, z));
  W.add(crate('TUBE', {x: L - 17, y: 0.65, z: -2.2, s: 1.2}), crate('KABEL', {x: L + 17, y: 0.65, z: -1.4, s: 1.2, ry: 0.3}));

  // --- radar machine + dish (year / choco) ---
  const cab = G(); cab.position.set(L - 5.8, 0, -2.6);
  cab.add(box(2.2, 2.4, 1.4, '#2f8f8a', {y: 1.2}), box(2.4, 0.15, 1.6, '#1f5e63', {y: 2.45}));
  cab.add(S('RADAR', 1.6, 0.46, 0, 2.0, 0.73, {bg: '#f2e6cc', w: 480, h: 140, font: FONT(88)}));
  for (let i = 0; i < 3; i++) { const dl = cyl(0.14, 0.14, 0.08, '#e9e2cf', {x: -0.6 + i * 0.6, y: 1.35, z: 0.72, seg: 14, thick: 0.01}); dl.rotation.x = Math.PI / 2; cab.add(dl); }
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.9, 14), bmat('#ffb066')); tube.position.set(0.3, 3.05, 0); cab.add(tube);
  cab.add(cyl(0.26, 0.26, 0.08, '#2b2b2e', {x: 0.3, y: 2.58}), cyl(0.26, 0.26, 0.08, '#2b2b2e', {x: 0.3, y: 3.52}));
  W.add(cab);
  W.add(box(0.14, 0.08, 2.2, '#2b2b2e', {x: L - 5.8, y: 0.08, z: -0.77}), box(0.14, 0.08, 1.0, '#2b2b2e', {x: L - 5.6, y: 0.08, z: 0.3}));
  const dishStand = G(); dishStand.position.set(L - 5.8, 0, 0.3);
  dishStand.add(box(0.9, 0.12, 0.9, '#3a3a3f', {y: 0.06}), cyl(0.1, 0.16, 1.15, '#6f6f74', {y: 0.7}));
  W.add(dishStand);
  const radarDish = dish(0.95, 'x-'); radarDish.position.set(L - 5.8, 1.35, 0.3); W.add(radarDish);
  const radarWaves = emitter(3.1, {r0: 0.2, r1: 0.95}); radarWaves.position.set(L - 6.5, 1.35, 0.3); radarWaves.rotation.y = -Math.PI / 2; W.add(radarWaves);

  // --- Percy Spencer (one character, moved between stations) ---
  const percy = character({palette: 'engineer', hat: 'none', glasses: true, seed: 5}); W.add(percy); chars.push(percy);
  const choc = chocolate(percy.userData.body);

  // --- corn station (x = 0) ---
  W.add(box(2.4, 0.1, 1.0, '#8a5a3b', {x: L, y: 0.95, z: -1.2}));
  for (const [x, z] of [[-1.1, -0.6], [1.1, -0.6], [-1.1, -1.8], [1.1, -1.8]]) W.add(box(0.12, 0.95, 0.12, '#6b4430', {x: L + x, y: 0.47, z, thick: 0.01}));
  W.add(cyl(0.34, 0.24, 0.14, '#b9c4ca', {x: L, y: 1.07, z: -1.2, seg: 18}));
  const pc = popcorn(L, 1.12, -1.2, 21); W.add(pc);
  const hornA = horn(); const hornAg = G(); hornAg.add(hornA); hornAg.position.set(L - 1.0, 1.25, -1.2); hornAg.rotation.y = Math.PI / 2; W.add(hornAg);
  W.add(cyl(0.06, 0.1, 1.2, '#6f6f74', {x: L - 1.0, y: 0.62, z: -1.2}));
  const cornWaves = emitter(0.9, {r0: 0.15, r1: 0.4, n: 4}); cornWaves.position.set(L - 0.62, 1.25, -1.2); cornWaves.rotation.y = Math.PI / 2; W.add(cornWaves);
  const sack = G(); sack.position.set(L + 0.95, 1.0, -1.1); sack.rotation.y = -0.25;
  sack.add(box(0.55, 0.7, 0.38, '#d9b36a', {y: 0.35}), S('JAGUNG', 0.46, 0.22, 0, 0.36, 0.2, {bg: '#f4ead4', w: 360, h: 170, font: FONT(76)}));
  W.add(sack);
  W.add(S('UJI COBA 1', 3.2, 0.8, L, 3.7, -5.9, {bg: '#f2c12e', w: 640, h: 160, font: FONT(80)}));
  const assistant = character({palette: 'mustard', hat: 'cap', seed: 14}); assistant.position.set(L + 1.8, 0.05, 0.1); W.add(assistant); chars.push(assistant);

  // --- egg station (x = 9) ---
  const E = L + 9;
  W.add(cyl(0.05, 0.09, 1.25, '#6f6f74', {x: E, y: 0.62, z: -0.35}), cyl(0.12, 0.07, 0.08, '#b9c4ca', {x: E, y: 1.2, z: -0.35}));
  const hornB = G(); hornB.add(horn()); hornB.position.set(E - 1.3, 1.3, -0.35); hornB.rotation.y = Math.PI / 2; W.add(hornB);
  W.add(cyl(0.06, 0.1, 1.3, '#6f6f74', {x: E - 1.3, y: 0.65, z: -0.35}));
  const eggWaves = emitter(0.85, {r0: 0.15, r1: 0.4, n: 4}); eggWaves.position.set(E - 0.92, 1.3, -0.35); eggWaves.rotation.y = Math.PI / 2; W.add(eggWaves);
  const egg = new THREE.Mesh(new THREE.SphereGeometry(0.12, 18, 14), toon('#f8ecd2')); egg.scale.set(1, 1.3, 1); egg.position.set(E, 1.39, -0.35); ink(egg, 0.02, false); W.add(egg);
  W.add(S('UJI COBA 2', 3.2, 0.8, E, 3.7, -5.9, {bg: '#f2c12e', w: 640, h: 160, font: FONT(80)}));
  const mate = character({palette: 'teal', hat: 'none', glasses: false, seed: 61}); mate.position.set(E, 0.05, -0.95); W.add(mate); chars.push(mate);
  // yolk splat + drips live on the colleague's head (head-local coordinates)
  const splat = G(); splat.position.set(0.02, -0.03, 0.065);
  const sp1 = new THREE.Mesh(splatShape(0.25, 3), bmat(INK)); sp1.scale.setScalar(1.08); sp1.position.z = 0;
  const sp2 = new THREE.Mesh(splatShape(0.24, 3), bmat('#fff6dc')); sp2.position.z = 0.002;
  const sp3 = new THREE.Mesh(splatShape(0.13, 9, 10), bmat('#f4c52a')); sp3.position.set(0.02, -0.02, 0.004);
  splat.add(sp1, sp2, sp3);
  const dripY = []; for (const dx of [-0.1, 0.06, 0.17]) { const dr = new THREE.Mesh(new THREE.PlaneGeometry(0.05, 1), bmat('#f4c52a')); dr.position.x = dx; splat.add(dr); dripY.push(dr); }
  mate.userData.head.add(splat); splat.visible = false;
  const shardGeo = new THREE.IcosahedronGeometry(0.05, 0), shardMat = toon('#f8ecd2'), yolkMat = toon('#f4c52a');
  const bits = Array.from({length: 14}, (_, i) => { const m = new THREE.Mesh(shardGeo, i < 7 ? shardMat : yolkMat); ink(m, 0.012, false); W.add(m); const r = rng(40 + i); return {m, yolk: i >= 7, vx: (r() - 0.5) * 3.2, vy: 1.2 + r() * 2, vz: 0.4 + r() * 1.8, tx: (r() - 0.5) * 0.3, ty: 1.55 + (r() - 0.5) * 0.25}; });

  // =====================================================================
  // PANGGUNG GELOMBANG (shot: wave) - dark stage, cutaway of food
  // =====================================================================
  const V = LOC.wave;
  W.add(room(V, {w: 34, h: 10, d: 16, wall: '#22346e', floor: '#16224a', seed: 31, stains: 4}));
  const grid = new THREE.BufferGeometry(); const gp = [];
  for (let x = -16; x <= 16; x++) gp.push(V + x, 0.07, -7.8, V + x, 0.07, 7.8);
  for (let z = -7; z <= 7; z++) gp.push(V - 16.8, 0.07, z, V + 16.8, 0.07, z);
  grid.setAttribute('position', new THREE.Float32BufferAttribute(gp, 3));
  W.add(new THREE.LineSegments(grid, new THREE.LineBasicMaterial({color: '#4f86ff', transparent: true, opacity: 0.55})));
  const wDish = dish(1.15, 'x+'); wDish.position.set(V - 8.5, 1.9, 0); W.add(wDish);
  W.add(cyl(0.16, 0.26, 1.8, '#8d9199', {x: V - 8.9, y: 0.9}), box(1.4, 0.18, 1.4, '#3a3a3f', {x: V - 8.9, y: 0.09}));
  const wWaves = emitter(9.5, {r0: 0.3, r1: 1.5, n: 9, color: '#7fe7ff'}); wWaves.position.set(V - 7.7, 1.9, 0); wWaves.rotation.y = Math.PI / 2; W.add(wWaves);
  // translucent food block with molecules inside
  const BX = V + 1.2, BY = 1.6;
  W.add(box(3.6, 0.22, 2.8, '#d8dde2', {x: BX, y: 0.11, thick: 0.02}));
  const glass = new THREE.Mesh(new THREE.BoxGeometry(3, 2.6, 2.2), new THREE.MeshBasicMaterial({color: '#f2c27a', transparent: true, opacity: 0.2, depthWrite: false}));
  glass.position.set(BX, BY, 0); W.add(glass);
  for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
    W.add(box(0.07, 0.07, 2.2, '#ffe9b8', {x: BX + sx * 1.5, y: BY + sy * 1.3, edges: false, thick: 0.001}));
    W.add(box(3.0, 0.07, 0.07, '#ffe9b8', {x: BX, y: BY + sy * 1.3, z: sx * 1.1, edges: false, thick: 0.001}));
    W.add(box(0.07, 2.6, 0.07, '#ffe9b8', {x: BX + sx * 1.5, y: BY, z: sy * 1.1, edges: false, thick: 0.001}));
  }
  const mols = []; const cA = new THREE.Color('#6fc3ff'), cB = new THREE.Color('#ff6a2e');
  for (let i = 0; i < 5; i++) for (let j = 0; j < 4; j++) for (let k = 0; k < 3; k++) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 8), new THREE.MeshBasicMaterial({color: '#6fc3ff'}));
    const bx = BX - 1.0 + i * 0.5, by = BY - 0.75 + j * 0.5, bz = -0.55 + k * 0.55; m.position.set(bx, by, bz); W.add(m);
    const dist = Math.hypot((i - 2) / 2, (j - 1.5) / 1.5, (k - 1) / 1);
    mols.push({m, bx, by, bz, dist, ph: (i * 7 + j * 3 + k) * 1.3});
  }
  const wSign1 = S('GELOMBANG MIKRO', 5.6, 1.0, V - 8.5, 4.4, -1.5, {bg: '#10183a', fg: '#7fe7ff', w: 1000, h: 170, font: FONT(96)});
  const wSign2 = S('PANAS DARI DALAM', 6.4, 1.1, BX, 5.3, -6.9, {bg: '#ff6a2e', fg: '#fff4dc', w: 900, h: 160, font: FONT(100)});
  const wSign3 = S('MAKANAN', 2.8, 0.7, BX, 3.7, 1.3, {bg: '#f2e6cc', w: 560, h: 140, font: FONT(92)});
  W.add(wSign1, wSign2, wSign3);
  const stu = character({palette: 'student', hat: 'cap', glasses: true, seed: 71}); stu.position.set(V + 5.6, 0.05, 0.8); W.add(stu); chars.push(stu);
  const ohh = S('OHH!', 1.8, 0.9, V + 5.6, 2.8, 0.8, {bg: '#f2c12e', w: 360, h: 180, font: FONT(110)}); W.add(ohh);
  for (const x of [-9, -4, 1, 6, 11]) { const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 1.4, 8.5, 16, 1, true), bmat('#7fe7ff', {transparent: true, opacity: 0.06, depthWrite: false, side: THREE.DoubleSide})); sh.position.set(V + x, 4.9, -2); W.add(sh); W.add(cyl(0.3, 0.45, 0.5, '#2f3a6b', {x: V + x, y: 9.4, z: -2})); }
  const NP = 90; const pg = new THREE.BufferGeometry(); const pp = new Float32Array(NP * 3); pg.setAttribute('position', new THREE.BufferAttribute(pp, 3));
  const rp = rng(9); const pseed = Array.from({length: NP}, () => [rp(), rp(), rp(), rp()]);
  W.add(new THREE.Points(pg, new THREE.PointsMaterial({color: '#9fd8ff', size: 0.16, transparent: true, opacity: 0.8, depthWrite: false})));

  // =====================================================================
  // PABRIK OVEN 1947 (shot: oven)
  // =====================================================================
  const F = LOC.factory;
  W.add(room(F, {w: 30, h: 8.5, d: 14, wall: '#d8cdb4', floor: '#8f7a60', seed: 41}));
  for (let i = 0; i < 6; i++) W.add(box(30, 0.35, 0.3, '#5a5f66', {x: F, y: 8.2, z: -6 + i * 2.4, thick: 0.02}));
  for (let i = 0; i < 7; i++) W.add(box(0.3, 0.35, 14, '#5a5f66', {x: F - 12 + i * 4, y: 7.8, z: 0, thick: 0.02}));
  for (const x of [-9, -3, 3, 9]) hang(W, F + x, 6.6, -1, '#9a6f40');
  W.add(S('RADARANGE', 7.0, 1.3, F, 5.8, -6.9, {bg: '#c43d32', fg: '#fff4dc', w: 960, h: 180, font: FONT(116)}));
  W.add(at(P.rug(7, 4.5, '#3e5a7a', '#d9a441'), F, 0.06, -0.6));
  // the oven: ~1.8 m tall
  const OX = F, OZ = -1.2;
  const oven = G(); oven.position.set(OX, 0, OZ); W.add(oven);
  oven.add(box(1.5, 0.18, 1.4, '#4a4f58', {y: 0.09}));
  oven.add(box(1.0, 1.8, 0.9, '#e9e2cf', {y: 1.08}));
  oven.add(box(0.8, 0.95, 0.06, '#8a8f96', {y: 0.9, z: 0.48}), box(0.62, 0.7, 0.03, '#bfe3f5', {y: 0.92, z: 0.5, thick: 0.006, edges: false}));
  oven.add(box(1.02, 0.28, 0.92, '#c43d32', {y: 1.8}));
  oven.add(S('RADARANGE', 0.9, 0.2, 0, 1.8, 0.47, {bg: '#c43d32', fg: '#fff4dc', w: 540, h: 120, font: FONT(72), border: false}));
  for (let i = 0; i < 3; i++) { const dl = cyl(0.07, 0.07, 0.06, '#2b2b2e', {x: -0.28 + i * 0.28, y: 1.48, z: 0.47, seg: 12, thick: 0.01}); dl.rotation.x = Math.PI / 2; oven.add(dl); }
  oven.add(box(0.06, 0.5, 0.06, '#cfcfcf', {x: 0.36, y: 0.9, z: 0.55, thick: 0.01}));
  const tag = S('DIJUAL', 0.9, 0.4, 0, 1.3, 0.56, {bg: '#c43d32', fg: '#fff4dc', w: 360, h: 160, font: FONT(80)}); oven.add(tag);
  W.add(S('1947', 2.4, 1.0, F, 3.9, OZ, {bg: '#f4ead4', w: 480, h: 200, font: FONT(130)}));
  W.add(cyl(0.02, 0.02, 4.0, '#2b2b2e', {x: F - 0.9, y: 6.0, z: OZ}), cyl(0.02, 0.02, 4.0, '#2b2b2e', {x: F + 0.9, y: 6.0, z: OZ}));
  // height ruler
  const RX = F - 1.7;
  W.add(box(0.14, 2.3, 0.14, '#d9a441', {x: RX, y: 1.15, z: -0.6, thick: 0.01}));
  for (let i = 1; i <= 10; i++) W.add(box(i % 5 ? 0.18 : 0.32, 0.03, 0.04, INK, {x: RX + 0.16, y: i * 0.2, z: -0.52, thick: 0.002, edges: false}));
  const marker = box(0.7, 0.05, 0.05, '#e0533d', {x: RX + 0.45, y: 0.2, z: -0.5, thick: 0.01}); W.add(marker);
  const hSign = S('HAMPIR 2 M', 1.9, 0.5, RX - 0.1, 2.75, -0.5, {bg: '#f2e6cc', w: 600, h: 160, font: FONT(88)}); W.add(hSign);
  // weight readout
  const wB = G(); wB.position.set(F + 1.9, 0, -0.3);
  wB.add(cyl(0.05, 0.05, 1.0, '#3a3a3f', {x: -0.75, y: 0.5}), cyl(0.05, 0.05, 1.0, '#3a3a3f', {x: 0.75, y: 0.5}));
  wB.add(S('300+ KG', 1.9, 0.8, 0, 1.2, 0, {bg: '#10183a', fg: '#7dff9a', w: 640, h: 270, font: FONT(150)}));
  W.add(wB);
  // factory dress
  [[-11, -6.4], [-8, -6.4], [8, -6.4], [11, -6.4]].forEach(([x, z], i) => W.add(at(P.bookshelf(i + 20, 2.4, 3.0), F + x, 0.05, z + 0.4)));
  W.add(at(P.toolRack(3), F - 4.5, 0, -6.9), at(P.toolRack(1), F + 4.5, 0, -6.9));
  for (const [x, z] of [[-13, 3], [-13, -2], [13, 3], [13, -2]]) { W.add(at(P.barrel(['#2f6db3', '#c43d32', '#d9a441', '#4f8a4a'][Math.abs(x + z) % 4]), F + x, 0.05, z)); }
  W.add(at(P.pallet(), F - 8, 0.05, -2.5), at(P.pallet(), F + 8, 0.05, -3.2));
  W.add(crate('RADAR', {x: F - 8, y: 0.8, z: -2.5, s: 1.3}), crate('TUBE', {x: F + 8, y: 0.8, z: -3.2, s: 1.3, ry: 0.4}));
  W.add(at(P.beamStack(4, 4), F + 11.5, 0.05, 1.8), at(P.ladder(3.4), F - 12.8, 0.05, -5.8));
  W.add(at(P.toolbox(), F + 5.5, 0.05, -0.8), at(P.toolbox(), F - 5.5, 0.05, 0.6, 0.5));
  // second, unfinished oven frame on a bench
  W.add(box(1.0, 1.8, 0.9, '#8d9199', {x: F + 6.6, y: 0.9, z: -3.6}), box(1.4, 0.2, 1.2, '#7a4f33', {x: F + 6.6, y: 0.1, z: -3.6}));
  W.add(S('BARU!', 1.2, 0.5, F + 6.6, 1.3, -3.1, {bg: '#f2c12e', w: 300, h: 120, font: FONT(72)}));
  const wk1 = character({palette: 'welder', hat: 'cap', seed: 91}); wk1.position.set(F + 8.0, 0.05, -2.2); W.add(wk1); chars.push(wk1);
  const wk2 = character({palette: 'mustard', hat: 'cap', glasses: true, seed: 92}); wk2.position.set(F - 4.2, 0.05, -2.8); W.add(wk2); chars.push(wk2);
  const wk3 = character({palette: 'navy', hat: 'bowler', seed: 93}); wk3.position.set(F + 4.4, 0.05, 1.2); W.add(wk3); chars.push(wk3);

  // =====================================================================
  // DAPUR MODERN (shot: close)
  // =====================================================================
  const K = LOC.kitchen;
  W.add(room(K, {w: 20, h: 5, d: 10, wall: '#f2dfb0', floor: '#c9b08a', seed: 51}));
  W.add(box(20, 1.2, 0.1, '#7fb3cf', {x: K, y: 1.55, z: -4.9, edges: false, thick: 0.001}));
  W.add(box(14, 0.95, 0.75, '#2f8f8a', {x: K + 1, y: 0.475, z: -4.55}), box(14.2, 0.1, 0.85, '#f4ead4', {x: K + 1, y: 1.0, z: -4.55}));
  for (let i = 0; i < 6; i++) W.add(box(2.2, 1.2, 0.6, '#2f8f8a', {x: K - 5 + i * 2.4, y: 3.5, z: -4.7}), box(0.05, 0.4, 0.04, '#f4ead4', {x: K - 4.1 + i * 2.4, y: 3.3, z: -4.38, edges: false, thick: 0.001}));
  W.add(box(1.1, 2.3, 0.95, '#e9e2cf', {x: K - 8.2, y: 1.15, z: -4.4}), box(0.05, 0.9, 0.05, '#9aa0a8', {x: K - 7.75, y: 1.5, z: -3.9, thick: 0.004}));
  W.add(S('', 2.6, 1.7, K + 5.2, 2.7, -4.95, {bg: '#bfe3f5', border: true}), box(0.5, 1.9, 0.06, '#c43d32', {x: K + 3.75, y: 2.7, z: -4.88}), box(0.5, 1.9, 0.06, '#c43d32', {x: K + 6.65, y: 2.7, z: -4.88}));
  W.add(S('RADAR', 1.1, 0.9, K - 0.95, 2.4, -4.95, {bg: '#c9b27a', w: 400, h: 310, font: FONT(88), sub: '1945'}));
  W.add(at(P.wallClock(), K + 3.0, 4.2, -4.9));
  for (const x of [-3, 3, 7]) hang(W, K + x, 4.3, -1, '#c43d32');
  W.add(at(P.rug(6, 3.4, '#a8433a', '#e0b04a'), K, 0.06, -1.6));
  // kitchen table + plates
  W.add(box(2.6, 0.1, 1.4, '#8a5a3b', {x: K - 1.0, y: 0.8, z: -0.4}));
  for (const [x, z] of [[-1.2, -0.55], [1.2, -0.55], [-1.2, 0.55], [1.2, 0.55]]) W.add(box(0.1, 0.8, 0.1, '#6b4430', {x: K - 1.0 + x, y: 0.4, z: -0.4 + z, thick: 0.01}));
  for (const x of [-0.5, 0.5]) W.add(cyl(0.25, 0.22, 0.04, '#f4ead4', {x: K - 1.0 + x, y: 0.87, z: -0.4}));
  W.add(at(P.mug('#2f6db3'), K - 1.0, 0.85, -0.2), at(P.chair('#c43d32'), K - 2.4, 0.05, -0.4, Math.PI / 2), at(P.chair('#c43d32'), K + 0.4, 0.05, -0.4, -Math.PI / 2));
  // counter things
  W.add(cyl(0.18, 0.2, 0.32, '#c43d32', {x: K - 5.5, y: 1.2, z: -4.5}), cyl(0.2, 0.2, 0.35, '#d9a441', {x: K - 4.8, y: 1.22, z: -4.6}));
  W.add(at(P.papers(4, 5), K + 4.8, 1.05, -4.4), at(P.mug('#d9a441'), K + 5.6, 1.05, -4.4));
  for (let i = 0; i < 3; i++) W.add(cyl(0.2 + i * 0.03, 0.2 + i * 0.03, 0.05, '#8d9199', {x: K - 6.2 + i * 0.5, y: 3.0, z: -4.9}));
  W.add(S('DAPUR', 1.6, 0.5, K - 6.6, 4.3, -4.95, {bg: '#f2e6cc', w: 400, h: 130, font: FONT(84)}));
  // the microwave (scaled up a little for the camera)
  const mw = G(); mw.position.set(K + 0.9, 1.05, -4.35); mw.scale.setScalar(1.25); W.add(mw);
  mw.add(box(0.8, 0.46, 0.5, '#d8dde2', {y: 0.23}));
  const winGlow = new THREE.MeshBasicMaterial({color: '#ffcf7d'});
  const doorWin = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.32, 0.03), winGlow); doorWin.position.set(-0.1, 0.23, 0.26); mw.add(doorWin);
  mw.add(box(0.2, 0.4, 0.03, '#9aa0a8', {x: 0.31, y: 0.23, z: 0.26, thick: 0.006}));
  mw.add(S('0:30', 0.15, 0.07, 0.31, 0.38, 0.285, {bg: '#10183a', fg: '#7dff9a', w: 150, h: 70, font: FONT(46), border: false}));
  for (let i = 0; i < 3; i++) mw.add(cyl(0.025, 0.025, 0.03, '#2b2b2e', {x: 0.31, y: 0.26 - i * 0.07, z: 0.285, seg: 8, thick: 0.004}));
  const plate = G(); plate.position.set(-0.1, 0.1, 0.0); mw.add(plate);
  plate.add(cyl(0.17, 0.17, 0.02, '#f4ead4', {y: 0}));
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), toon('#e0533d', null, {side: THREE.DoubleSide})); bowl.position.y = 0.12; ink(bowl, 0.008, false); plate.add(bowl);
  const rice = new THREE.Mesh(new THREE.SphereGeometry(0.105, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), toon('#fffaf0')); rice.position.y = 0.12; ink(rice, 0.008, false); plate.add(rice);
  const steamMat = bmat('#ffffff', {transparent: true, opacity: 0.55, depthWrite: false});
  const steam = Array.from({length: 9}, () => { const s = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), steamMat); mw.add(s); return s; });
  const ting = S('TING!', 0.7, 0.3, 0.0, 0.85, 0.2, {bg: '#f2c12e', w: 420, h: 180, font: FONT(110)}); mw.add(ting);
  const mom = character({palette: 'pink', hat: 'none', glasses: false, seed: 81}); mom.position.set(K - 3.6, 0.05, -2.9); W.add(mom); chars.push(mom);
  const kid = character({palette: 'student', hat: 'cap', seed: 82, scale: 0.7}); kid.position.set(K + 3.4, 0.05, -2.8); W.add(kid); chars.push(kid);

  // =====================================================================
  // per-frame update
  // =====================================================================
  const SPOT = {hook: [L - 9.5, 0.05, 0.3], year: [L - 9.5, 0.05, 0.3], choco: [L - 9.5, 0.05, 0.3], corn: [L - 0.9, 0.05, 0.2], egg: [L + 11.3, 0.05, 0.3]};
  const update = (t, cam, shot) => {
    const sp = SPOT[shot]; percy.visible = !!sp; if (sp) percy.position.set(sp[0], sp[1], sp[2]);
    for (const c of chars) c.userData.update(t, cam.position);
    percy.userData.armR.rotation.z = shot === 'corn' ? 1.7 * ease(t, wordT('corn', 2), wordT('corn', 2) + 0.35) * (1 - ease(t, wordT('corn', 6), wordT('corn', 6) + 0.4)) : 0;
    // chocolate melts on "meleleh"
    const mm = shot === 'hook' ? ease(t, wordT('hook', 5), wordT('hook', 5) + 1.0) : shot === 'choco' ? ease(t, wordT('choco', 5), wordT('choco', 5) + 1.0) : 0;
    choc.userData.update(mm, t);
    // radar waves
    const on = shot === 'hook' ? ease(t, wordT('hook', 3), wordT('hook', 3) + 0.4) : shot === 'year' ? ease(t, wordT('year', 11), wordT('year', 11) + 0.4) : shot === 'choco' ? 1 : 0;
    radarWaves.userData.update(t, on, 0.6);
    tube.material.color.setHSL(0.08, 1, 0.55 + 0.1 * Math.sin(t * 9) * on);
    // corn
    pc.userData.update(t, wordT('corn', 8));
    cornWaves.userData.update(t, shot === 'corn' ? ease(t, wordT('corn', 5), wordT('corn', 5) + 0.4) : 0, 0.9);
    // egg
    const boom = wordT('egg', 6), tau = t - boom;
    const sh = ease(t, wordT('egg', 4), boom);
    egg.visible = t < boom; egg.position.x = E + Math.sin(t * 61) * 0.02 * sh; egg.rotation.z = Math.sin(t * 47) * 0.12 * sh; egg.scale.set(1 + 0.2 * sh, 1.3 + 0.1 * sh, 1 + 0.2 * sh);
    eggWaves.userData.update(t, shot === 'egg' ? ease(t, wordT('egg', 3), wordT('egg', 3) + 0.4) * (t < boom ? 1 : 0.4) : 0, 0.9);
    for (const b of bits) {
      b.m.visible = tau > 0 && tau < 3 && shot === 'egg';
      if (!b.m.visible) continue;
      if (b.yolk) { const k = ease(tau, 0, 0.28); b.m.visible = tau < 0.3; b.m.position.set(E + (b.tx) * k, 1.39 + (b.ty - 1.39) * k, -0.35 + (-0.78 + 0.35) * k); }
      else b.m.position.set(E + b.vx * tau, Math.max(0.1, 1.39 + b.vy * tau - 4.5 * 9 / 9 * tau * tau), -0.35 + b.vz * tau);
      b.m.rotation.set(tau * 6, tau * 4, 0);
    }
    splat.visible = tau > 0.22; const ss = ease(tau, 0.22, 0.5); splat.scale.setScalar(Math.max(0.001, ss));
    const dl = ease(tau, 0.5, 2.2); dripY.forEach((d, i) => { const len = (0.12 + 0.3 * dl) * (0.7 + i * 0.25); d.scale.y = len; d.position.y = -0.18 - len / 2; });
    // wave stage
    const wOn = shot === 'wave' ? ease(t, wordT('wave', 0), wordT('wave', 0) + 0.5) : 0;
    wWaves.userData.update(t, wOn, 0.5);
    pop(wSign1, t, wordT('wave', 0)); pop(wSign3, t, wordT('wave', 6)); pop(wSign2, t, wordT('wave', 7)); pop(ohh, t, wordT('wave', 9));
    const h0 = wordT('wave', 5);
    for (const q of mols) {
      const hh = ease(t, h0 + q.dist * 1.1, h0 + q.dist * 1.1 + 0.8);
      q.m.material.color.copy(cA).lerp(cB, hh);
      const amp = 0.015 + 0.07 * hh;
      q.m.position.set(q.bx + Math.sin(t * 28 + q.ph) * amp, q.by + Math.cos(t * 31 + q.ph) * amp, q.bz + Math.sin(t * 25 + q.ph * 2) * amp);
      q.m.scale.setScalar(1 + 0.25 * hh);
    }
    for (let i = 0; i < NP; i++) { const [a, b, c, d] = pseed[i]; pp[i * 3] = V - 15 + a * 30; pp[i * 3 + 1] = 0.5 + ((b * 9 + t * (0.3 + d * 0.5)) % 9); pp[i * 3 + 2] = -7 + c * 14; }
    pg.attributes.position.needsUpdate = true;
    // factory: ruler marker rises to the top of the oven on "dua meter"
    marker.position.y = 0.2 + (1.98 - 0.2) * ease(t, wordT('oven', 6), wordT('oven', 9));
    pop(tag, t, wordT('oven', 5)); pop(hSign, t, wordT('oven', 8)); pop(wB, t, wordT('oven', 12));
    wB.position.y = 0;
    // kitchen: microwave runs on "menghangatkan"
    const run = ease(t, wordT('close', 5), wordT('close', 5) + 0.4);
    winGlow.color.setHSL(0.09, 1, 0.55 + 0.1 * Math.sin(t * 8) * run);
    plate.rotation.y = (t > wordT('close', 5) ? (t - wordT('close', 5)) * 1.8 : 0);
    steam.forEach((s, i) => { const k = (((t * 0.55 + i / 9) % 1) + 1) % 1; s.visible = run > 0.5; s.position.set(-0.1 + Math.sin(i * 2.1 + t * 2) * 0.05, 0.28 + k * 0.28, Math.cos(i * 1.7) * 0.05); s.scale.setScalar(Math.max(0.01, (1 - k) * (0.8 + 0.3 * (i % 3)))); });
    pop(ting, t, wordT('close', 7));
    mom.userData.armR.rotation.z = shot === 'close' ? 0.5 + Math.sin(t * 3) * 0.2 : 0;
  };

  return {group: W, update};
}
