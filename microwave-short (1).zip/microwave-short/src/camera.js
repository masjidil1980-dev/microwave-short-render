import * as THREE from 'three';
import timing from './timing.json';

// monotone cubic time warp: beat times per path key -> path position 0..1 (ease in/out)
export function warpU(T, t) {
  const n = T.length; if (t <= T[0]) return 0; if (t >= T[n - 1]) return 1;
  const sec = []; for (let i = 0; i < n - 1; i++) sec.push((1 / (n - 1)) / (T[i + 1] - T[i]));
  const m = [0]; for (let i = 1; i < n - 1; i++) m.push(2 * sec[i - 1] * sec[i] / (sec[i - 1] + sec[i])); m.push(0);
  let i = 0; while (t > T[i + 1]) i++;
  const h = T[i + 1] - T[i], x = (t - T[i]) / h, x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) + (x3 - 2 * x2 + x) * h * m[i] + (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) + (x3 - x2) * h * m[i + 1];
}

const S = Object.fromEntries(timing.shots.map((s) => [s.key, s]));
const keys = timing.shots.map((s) => s.key);
// cut = midway between the end of one sentence and the start of the next
export const CUTS = keys.map((k, i) => (i === 0 ? 0 : (timing.shots[i - 1].end + timing.shots[i].start) / 2));
export const END = timing.duration;
// word time: proportional position of word index (0-based) inside a sentence
export const wordT = (key, idx) => S[key].start + (S[key].end - S[key].start) * idx / S[key].words;

// light presets (all scenes are indoors / on a stage; sky only matters for the shader behind the walls)
const INDOOR = {sun: '#fff4e4', si: 1.6, sky: '#f4fbff', gnd: '#b48a62', hi: 1.05, fog: '#efe2cb', near: 60, far: 160, sunOff: [-6, 9, 7], shadow: 14, top: '#7fb7e6', hor: '#d6ecf6'};
export const LIGHTS = {
  lab: {...INDOOR, fog: '#d6ecf0', pt: {c: '#ffc77a', i: 7, p: [-1.5, 3.8, 1.2], d: 14}},
  stage: {sun: '#9fb4ff', si: 0.7, sky: '#8fa4ff', gnd: '#1a2350', hi: 1.0, fog: '#141d44', near: 50, far: 140, sunOff: [-6, 9, 7], shadow: 14, top: '#0c1236', hor: '#1d2a66', pt: {c: '#7fe7ff', i: 10, p: [0, 5, 3], d: 22}},
  factory: {...INDOOR, si: 1.5, gnd: '#a07850', fog: '#e8d9bd', pt: {c: '#ffc77a', i: 8, p: [0, 5, 2], d: 20}},
  kitchen: {...INDOOR, si: 1.8, hi: 1.15, gnd: '#c49a6a', fog: '#f1e2c8', top: '#8fc3ee', pt: {c: '#ffd58a', i: 7, p: [0.5, 3.6, -1], d: 16}},
};

const v = (a) => new THREE.Vector3(...a);
// camera plan: per shot, location light, anchor (for the light), path keys {p, l}, optional beat times.
// l (look-at) is always the exact centre of the object named at that word, so the subject sits in the middle of the frame.
export const PLAN = {
  hook: {light: 'lab', anchor: [-8, 0, 0], keys: [{p: [-9.0, 1.35, 1.5], l: [-9.35, 1.25, 0.4]}, {p: [-9.5, 1.75, 2.4], l: [-9.5, 1.6, 0.35]}, {p: [-7.0, 2.7, 4.6], l: [-6.8, 1.5, -1.0]}], beats: 'words:hook:0,4,8'},
  year: {light: 'lab', anchor: [-8, 0, 0], keys: [{p: [-12, 3.5, -3.3], l: [-12, 3.6, -5.9]}, {p: [-9.7, 1.7, 2.3], l: [-9.5, 1.5, 0.3]}, {p: [-3.6, 2.3, 2.8], l: [-5.8, 1.8, -0.3]}], beats: 'words:year:0,7,11'},
  choco: {light: 'lab', anchor: [-8, 0, 0], keys: [{p: [-3.6, 2.3, 2.8], l: [-5.8, 1.8, -0.3]}, {p: [-7.7, 1.6, 2.4], l: [-8.4, 1.3, 0.3]}, {p: [-8.7, 1.3, 1.5], l: [-9.35, 1.2, 0.4]}], beats: 'words:choco:0,3,6'},
  corn: {light: 'lab', anchor: [0, 0, 0], keys: [{p: [0.45, 1.9, 3.8], l: [0.45, 1.35, 0.2]}, {p: [0.4, 1.7, 1.9], l: [0.4, 1.1, -1.2]}, {p: [0.0, 1.9, 1.4], l: [0.0, 1.25, -1.2]}], beats: 'words:corn:0,5,8'},
  egg: {light: 'lab', anchor: [9, 0, 0], keys: [{p: [9.4, 2.0, 4.4], l: [9.4, 1.3, -0.4]}, {p: [9.0, 1.6, 1.9], l: [9.0, 1.4, -0.4]}, {p: [9.0, 1.75, 1.0], l: [9.0, 1.55, -0.85]}], beats: 'words:egg:0,5,9'},
  wave: {light: 'stage', anchor: [100, 0, 0], keys: [{p: [93.6, 2.6, 3.8], l: [91.9, 2.3, -0.2]}, {p: [96.6, 2.6, 3.4], l: [98.6, 1.8, 0]}, {p: [101.2, 2.1, 3.7], l: [101.2, 1.6, 0]}, {p: [104.2, 2.0, 3.6], l: [104.6, 1.7, 0.2]}], beats: 'words:wave:0,3,6,9'},
  oven: {light: 'factory', anchor: [200, 0, 0], keys: [{p: [200.4, 2.5, 4.0], l: [200, 1.9, -1.2]}, {p: [200.2, 1.6, 2.6], l: [200, 1.5, -1.2]}, {p: [199.5, 1.5, 1.9], l: [199.5, 1.1, -1.0]}, {p: [201.5, 1.3, 1.8], l: [201.5, 1.1, -0.3]}], beats: 'words:oven:0,5,8,12'},
  close: {light: 'kitchen', anchor: [300, 0, 0], keys: [{p: [300.0, 1.9, -1.7], l: [300.0, 1.9, -4.8]}, {p: [300.6, 1.7, -2.3], l: [300.8, 1.45, -4.3]}, {p: [300.85, 1.5, -2.8], l: [300.85, 1.34, -4.3]}], beats: 'words:close:0,3,6'},
};

// precompute curves + beat times
const CURVES = {};
keys.forEach((k, i) => {
  const P = PLAN[k];
  const a = CUTS[i], b = i + 1 < keys.length ? CUTS[i + 1] : END;
  let T;
  if (P.beats && P.beats.startsWith('words:')) {
    const [, key, idx] = P.beats.split(':');
    T = idx.split(',').map(Number).map((n) => wordT(key, n));
    T[0] = a; T[T.length - 1] = b;
  } else T = P.keys.map((_, j) => a + (b - a) * j / (P.keys.length - 1));
  CURVES[k] = {
    p: new THREE.CatmullRomCurve3(P.keys.map((q) => v(q.p)), false, 'centripetal'),
    l: new THREE.CatmullRomCurve3(P.keys.map((q) => v(q.l)), false, 'centripetal'),
    T, a, b,
  };
});

export function shotAt(t) {
  let i = 0; while (i + 1 < CUTS.length && t >= CUTS[i + 1]) i++;
  return keys[i];
}
export function cameraAt(t) {
  const k = shotAt(t); const C = CURVES[k];
  const u = warpU(C.T, t);
  return {key: k, pos: C.p.getPointAt(u), look: C.l.getPointAt(u), plan: PLAN[k], a: C.a, b: C.b};
}
// dip-to-cream opacity around location changes (0.4 s total)
const CONT = new Set(['choco']); // these shots continue the previous camera move
export function dipAt(t) {
  let o = 0;
  keys.forEach((k, i) => {
    if (i === 0 || CONT.has(k)) return;
    const c = CUTS[i]; const d = Math.abs(t - c);
    if (d < 0.2) o = Math.max(o, 1 - d / 0.2);
  });
  return o;
}
