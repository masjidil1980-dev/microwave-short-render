# Cokelat di Saku Insinyur (3D Story Short, 38 detik)

Naskah: dari pengguna (tidak diubah). Suara: ElevenLabs "Zephlyn", dirapatkan 1.10x oleh prepare_voice.py.

## Fact map (2 sumber independen)
| Klaim di video | Sumber 1 | Sumber 2 |
|---|---|---|
| 1945, Percy Spencer, dekat magnetron/radar aktif, cokelat di saku meleleh | History.com (microwave-oven-invention) | LiveScience (who-invented-microwave-oven) |
| Jagung (popcorn) meletus | History.com | LiveScience |
| Telur bergetar lalu meledak | LiveScience ("started to shake and then explode") | History.com (cangkang pecah) |
| Oven pertama 1947 (Radarange), ~5,5 kaki (1,7 m), 750 lb (340 kg) | LiveScience | History.com ("hampir enam kaki, 750 lb") |

## Catatan kehati-hatian
- "Konon" di shot choco sudah menandai ini kisah populer, bukan catatan resmi.
- "Meledak tepat di wajah rekannya" dan "menyuruh asistennya membeli jagung" adalah bagian cerita populer yang tidak ditemukan di dua sumber di atas. Visual adalah dramatisasi.
- "Hampir dua meter": sumber menyebut sekitar 1,7-1,8 m ("hampir enam kaki"). Tanda di video: "HAMPIR 2 M".
- Dijual 1947: LiveScience menulis "introduced"; History menyebut komersial pertama. Pertimbangkan "diperkenalkan" jika ingin ketat.
